
(function ($) {

    //sorting toggle
    $('.sorting span').on('click',function () {
        $(this).toggleClass('fa-sort-amount-asc fa-sort-amount-desc');
    });

    /*Externel Library init
     ------------------------*/
    // Star rating
    $(".stars").barrating({
        theme: 'fontawesome-stars'
    });
    //dropDown JS


})(jQuery);

