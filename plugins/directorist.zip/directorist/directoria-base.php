<?php
/**
Plugin Name: Directorist
Plugin URI: http://aazztech.com/plugins/directorist
Description: Create a professional directory listing website like Yelp by a few clicks only. You can list place, any business etc.  with this plugin very easily.
Version: 1.0.0
Author: AazzTech
Author URI: http://aazztech.com
License: GPLv2 or later
*/
/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Copyright 2017 AazzTech.com.
*/
// prevent direct access to the file
defined( 'ABSPATH' ) || die( 'No direct script access allowed!' );
/**
 * Main Directorist_Base Class.
 *
 * @since 1.0
 */
final class Directorist_Base {
    /** Singleton *************************************************************/

    /**
     * @var Directorist_Base The one true Directorist_Base
     * @since 1.0
     */
    private static $instance;


    /**
     * ATBDP_Metabox Object.
     *
     * @var object|ATBDP_Metabox
     * @since 1.0
     */
    public $metabox;


    /**
     * ATBDP_Custom_Post Object.
     *
     * @var object|ATBDP_Custom_Post
     * @since 1.0
     */
    public $custom_post;

    /**
     * ATBDP_Custom_Taxonomy Object.
     *
     * @var object|ATBDP_Custom_Taxonomy
     * @since 1.0
     */
    public $taxonomy;

    /**
     * ATBDP_Enqueuer Object.
     *
     * @var object|ATBDP_Enqueuer
     * @since 1.0
     */
    public $enquirer;


    /**
     * ATBDP_Ajax_Handler Object.
     *
     * @var object|ATBDP_Ajax_Handler
     * @since 1.0
     */
    public $ajax_handler;

    /**
     * ATBDP_Settings Object.
     *
     * @var object|ATBDP_Settings
     * @since 1.0
     */
    public $settings;

    /**
     * ATBDP_Shortcode Object.
     *
     * @var object|ATBDP_Shortcode
     * @since 1.0
     */
    public $shortcode;

    /**
     * ATBDP_Helper Object.
     *
     * @var object|ATBDP_Helper
     * @since 1.0
     */
    public $helper;


    /**
     * ATBDP_Review_Rating Object.
     *
     * @var object|ATBDP_Review_Rating
     * @since 1.0
     */
    public $review;

    /**
     * ATBDP_Listing Object.
     *
     * @var object|ATBDP_Listing
     * @since 1.0
     */
    public $listing;

    /**
     * ATBDP_User Object.
     *
     * @var object|ATBDP_User
     * @since 1.0
     */
    public $user;

    /**
     * Main Directorist_Base Instance.
     *
     * Insures that only one instance of Directorist_Base exists in memory at any one
     * time. Also prevents needing to define globals all over the place.
     *
     * @since 1.0
     * @static
     * @static_var array $instance
     * @uses Directorist_Base::setup_constants() Setup the constants needed.
     * @uses Directorist_Base::includes() Include the required files.
     * @uses Directorist_Base::load_textdomain() load the language files.
     * @see ATBDP()
     * @return object|Directorist_Base The one true Directorist_Base
     */
    public static function instance() {
        if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Directorist_Base ) ) {
            self::$instance = new Directorist_Base;
            self::$instance->setup_constants();

            add_action( 'plugins_loaded', array( self::$instance, 'load_textdomain' ) );
            add_action( 'widgets_init', array( self::$instance, 'register_widgets' ) );

            self::$instance->includes();
            self::$instance->custom_post = new ATBDP_Custom_Post; // create custom post
            self::$instance->settings       = new ATBDP_Settings(new ATBDP_Settings_API); // create admin panel settings
            self::$instance->taxonomy       = new ATBDP_Custom_Taxonomy;
            self::$instance->enquirer       = new ATBDP_Enqueuer;
            self::$instance->metabox        = new ATBDP_Metabox;
            self::$instance->ajax_handler   = new ATBDP_Ajax_Handler;
            self::$instance->shortcode      = new ATBDP_Shortcode;
            self::$instance->helper         = new ATBDP_Helper;
            self::$instance->listing        = new ATBDP_Listing;
            self::$instance->user           = new ATBDP_User;
            /*Extensions Link*/
            /*initiate extensions link*/
            new ATBDP_Extensions();
            /*Initiate Review and Rating Features*/
            self::$instance->review         = new ATBDP_Review_Rating;

        }

        return self::$instance;
    }

    /**
     * Throw error on object clone.
     *
     * The whole idea of the singleton design pattern is that there is a single
     * object therefore, we don't want the object to be cloned.
     *
     * @since 1.0
     * @access public
     * @return void
     */
    public function __clone() {
        // Cloning instances of the class is forbidden.
        _doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', ATBDP_TEXTDOMAIN ), '1.0' );
    }

    /**
     * Disable unserializing of the class.
     *
     * @since 1.0
     * @access public
     * @return void
     */
    public function __wakeup() {
        // Unserializing instances of the class is forbidden.
        _doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', ATBDP_TEXTDOMAIN ), '1.0' );
    }

    /**
     * It registers widgets and sidebar support
     *
     * @since 1.0
     * @access public
     * @return void
     */
    public function register_widgets()
    {
        if (!is_registered_sidebar('right-sidebar-listing') ) {
            register_sidebar( array(
                'name'          => __( 'Listing Right Sidebar', 'directorist' ),
                'id'            => 'right-sidebar-listing',
                'description'   => __( 'Add widgets for the right sidebar on single listing page', 'directorist' ),
                'before_widget' => '<div class="widget default">',
                'after_widget'  => '</div>',
                'before_title'  => '<div class="widget_title"><h4>',
                'after_title'  => '</h4></div>',

            ) );
        }
    }

    /**
     * Setup plugin constants.
     *
     * @access private
     * @since 1.0
     * @return void
     */
    private function setup_constants() {
        // test
        require_once plugin_dir_path(__FILE__).'/config.php'; // loads constant from a file so that it can be available on all files.
    }

    /**
     * Include required files.
     *
     * @access private
     * @since 1.0
     * @return void
     */
    private function includes() {
        require_once ATBDP_INC_DIR . 'helper-functions.php';
        require_once ATBDP_INC_DIR . 'login-register.php';
        load_dependencies('all', ATBDP_CLASS_DIR); // load all php files from ATBDP_CLASS_DIR
        load_dependencies('all', ATBDP_LIB_DIR); // load all php files from ATBDP_LIB_DIR
        /*LOAD Rating and Review functionality*/
        load_dependencies('all', ATBDP_INC_DIR . 'review-rating/');
    }

    public function load_textdomain()
    {
        load_plugin_textdomain(ATBDP_TEXTDOMAIN, false, ATBDP_LANG_DIR);
    }


    /**
     * It  loads a template file from the Default template directory.
     * @param string $name Name of the file that should be loaded from the template directory.
     * @param array $args Additional arguments that should be passed to the template file for rendering dynamic  data.
     */
    public function load_template($name, $args = array() ){
        $ATBDP = ATBDP();
        global $post, $ATBDP;
        include(ATBDP_TEMPLATES_DIR.$name.'.php');
    }

    public static function prepare_plugin()
    {
        include ATBDP_INC_DIR.'classes/class-installation.php';
        ATBDP_Installation::install();
    }



} // ends Directorist_Base












/**
 * The main function for that returns Directorist_Base
 *
 * The main function responsible for returning the one true Directorist_Base
 * Instance to functions everywhere.
 *
 * Use this function like you would a global variable, except without needing
 * to declare the global.
 *
 * Example: <?php $ATBDP = ATBDP(); ?>
 *
 * @since 1.0
 * @return object|Directorist_Base The one true Directorist_Base Instance.
 */
function ATBDP() {
    return Directorist_Base::instance();
}

// Get ATBDP ( AazzTech Business Directory Plugin) Running.
ATBDP();

register_activation_hook(__FILE__, array('Directorist_Base', 'prepare_plugin'));