<style>
    /* pagination Style */
    /*For adding dynamic styles later update or version*/
</style>