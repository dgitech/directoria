<section class="attc_extension_page">
    <div class="attc_extension_wrapper">
        <!--Reviews & Ratings-->
        <div class="single_extension">
            <img src="" alt="">

            <div class="extension_detail">
                <a href="#" class="ext_title"><h4>BD Extension: Reviews & Ratings </h4></a>
                <p>We all love to use the service or go to a place what user likes much. Letting your user provide reviews and rating for your business or service will increase your goodwill as well as your profit. You can implement the review and rating feature for your business or service using this extension.</p>

                <div class="btn_wrapper">
                    <a href="http://demos.aazztech.com/bd-extension-review-rating" target="_blank" class="btn demo">view demo</a>
                    <a href="http://aazztech.com/plugins/bd-extension-review-rating" target="_blank" class="btn get">Get extension</a>
                </div>
            </div>
        </div>
<!--related listings-->
        <div class="single_extension">
            <img src="" alt="">

            <div class="extension_detail">
                <a href="#" class="ext_title"><h4>BD Extension: Related Listings </h4></a>
                <p>You can show related listings by this extension.</p>

                <div class="btn_wrapper">
                    <a href="http://demos.aazztech.com/bd-extension-related-listing" target="_blank" class="btn demo">view demo</a>
                    <a href="http://aazztech.com/plugins/bd-extension-related-listing" target="_blank" class="btn get">Get extension</a>
                </div>
            </div>
        </div>
        <!--Popular listings-->
        <div class="single_extension">
            <img src="" alt="">

            <div class="extension_detail">
                <a href="#" class="ext_title"><h4>BD Extension: Popular Listings </h4></a>
                <p>You can show popular listings by this extension.</p>

                <div class="btn_wrapper">
                    <a href="http://demos.aazztech.com/bd-extension-popular-listing" target="_blank" class="btn demo">view demo</a>
                    <a href="http://aazztech.com/plugins/bd-extension-popular-listing" target="_blank" class="btn get">Get extension</a>
                </div>
            </div>
        </div>
    </div>
</section>