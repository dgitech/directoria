<?php
 $attachment_ids = (!empty($args['attachment_ids'])) ? $args['attachment_ids'] : array();
$image_links = []; // define a link placeholder variable
foreach ($attachment_ids as $id){
    $image_links[$id]= wp_get_attachment_image_src($id)[0]; // store the attachment id and url
}
?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="add_listing_form_wrapper" id="gallery_upload">

                        <div class="cmb-td">

                            <!-- image container, which can be manipulated with js -->
                            <div class="listing-img-container">
                                <?php if(!empty($image_links)) {
                                    foreach ($image_links as $id => $image_link) {
                                    ?>
                                    <div class="single_attachment"><input class="listing_image_attachment" name="listing[attachment_id][]" type="hidden" value="<?= intval($id); ?>"><img style="width: 100%; height: 100%;" src="<?= esc_url($image_link) ?>" alt="Listing Image"> <span class="remove_image  dashicons dashicons-dismiss" title="Remove it"></span></div>
                                <?php }  // ends foreach for looping image
                                } else { ?>
                                <img src="<?= esc_url( ATBDP_ADMIN_ASSETS.'images/no-image.jpg');?>" alt="No Image Found">
                                <?php } //  ends if statement  ?>
                            </div>

                            <!-- A hidden input to set and post the chosen image id -->
<!--                            <input id="listing_image_id" name="listing[attachment_id]" type="hidden" value="">-->


                            <!--  add & remove image links -->
                            <p class="hide-if-no-js">
                                <a href="#" id="listing_image_btn" class="btn btn-default ">
                                    <span class="dashicons dashicons-format-image"></span>
                                    Upload Image                        </a>
                                <a id="delete-custom-img" class="btn btn-default <?= (!empty($image_links)) ? '': 'hidden' ?>" href="#"> <?php _e('Remove Image', ATBDP_TEXTDOMAIN); ?></a>
                            </p>

                        </div>

                </div> <!--ends add_listing_form_wrapper-->

            </div> <!--ends col-md-12 -->
        </div>  <!--ends .row-->
    </div> <!--ends container-fluid-->
