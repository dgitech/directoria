<?php
/**
 * Template Name: Custom search result
 **/
get_header();

$ATBDP = ATBDP();
global $query_string;
global $wp_query;

$query_args = explode("&", $query_string);
$search_query = array();

if( strlen($query_string) > 0 ) {
    foreach($query_args as $key => $string) {
        $query_split = explode("=", $string);
        $search_query[$query_split[0]] = urldecode($query_split[1]);
    } // foreach
} //if
/*
 * NOTES: if user provide any invalid term of a taxonomy then the WordPress will generate notice about accessing the property of non object.
 * Because the taxonomy must exist and should have terms no matter it has posts or items attached to that
 * for example. Location Taxonomy May have Term Like Sylhet. and Sylhet may or may not have any posts attached to it
 *
 *
 *
 * */
$search = new WP_Query($search_query);


//for pagination
if ( get_query_var('paged') ) {
    $paged = get_query_var('paged');
} elseif ( get_query_var('page') ) {
    $paged = get_query_var('page');
} else {
    $paged = 1;
}
$in_cat = get_query_var(ATBDP_CATEGORY) ? get_query_var(ATBDP_CATEGORY) : '';
$in_loc = get_query_var(ATBDP_LOCATION) ? get_query_var(ATBDP_LOCATION) : '';
$s_string = get_search_query(false) ? get_search_query() : '';
?>


    <section class="directory_wrapper single_area">
        <div class="header_bar">
            <div class="<?php echo is_directoria_active() ? 'container': 'container-fluid'; ?>">
                <div class="row">
                    <div class="col-md-12">


                        <div class="header_form_wrapper">
                            <div class="directory_title">
                                <h3>
                                    <?php
                                    // show appropriate text for the search
                                    // possible search system




                                    if (!empty($s_string)&& !empty($in_cat) && !empty($in_loc)){
                                        //8. with everything
                                        printf(__('Search Result for: "%s" in "%s" Category in "%s" Location', ATBDP_TEXTDOMAIN), $s_string, $in_cat, $in_loc);

                                    }elseif(empty($s_string) && empty($in_cat) && empty($in_loc)){
                                        //1. empty q, loc and cat X
                                     _e('Showing Result from all categories and locations.', ATBDP_TEXTDOMAIN);

                                    }elseif(!empty($s_string) && !empty($in_loc) && empty($in_cat)){
                                        //3. only q and loc X
                                        printf(__('Showing Result for: "%s" in "%s" Location', ATBDP_TEXTDOMAIN), $s_string, $in_loc);

                                    }elseif(!empty($s_string) && !empty($in_cat) && empty($in_loc)){
                                        //4. only q and cat X
                                        printf(__('Showing Result for: "%s" in "%s" Category', ATBDP_TEXTDOMAIN), $s_string, $in_cat);

                                    }elseif(empty($s_string) && !empty($in_cat) && empty($in_loc)){
                                        //5. only cat
                                        printf(__('Showing Result in: "%s" Category', ATBDP_TEXTDOMAIN), $in_cat);

                                    }elseif(empty($s_string) && empty($in_cat) && !empty($in_loc)){
                                        //5. only loc
                                        printf(__('Showing Result in: "%s" Location', ATBDP_TEXTDOMAIN), $in_loc);

                                    }elseif(empty($s_string) && !empty($in_cat) && !empty($in_loc)){
                                        //6. only cat and loc
                                        printf(__('Showing Result in: "%s" Category and "%s" Location', ATBDP_TEXTDOMAIN),  $in_cat, $in_loc);

                                    }else{
                                        //2. only q X
                                        printf(__('Search Result for: "%s" from All categories and locations', ATBDP_TEXTDOMAIN), $s_string);
                                    }

                                    ?>
                                </h3>
                                <p><?php _e('Total Listing Found: ', ATBDP_TEXTDOMAIN); echo $wp_query->found_posts; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row" data-uk-grid>


                <?php if ( have_posts() ) {
                    while ( have_posts() ) { the_post(); ?>
                        <?php
                        /*RATING RELATED STUFF STARTS*/
                        $reviews = $ATBDP->review->db->count(array('post_id' => get_the_ID()));
                        $average = $ATBDP->review->get_average(get_the_ID());

                        /*RATING RELATED STUFF ENDS*/
                        $info = $ATBDP->metabox->get_listing_info(get_the_ID()); // get all post meta and extract it.
                        extract($info);
                        // get only one parent or high level term object
                        $single_parent = $ATBDP->taxonomy->get_one_high_level_term(get_the_ID(), ATBDP_CATEGORY);
                        ?>

                        <div class="col-md-4 col-sm-6">
                            <div class="single_direcotry_post">
                                <article>
                                    <figure>
                                        <div class="post_img_wrapper">
                                            <?= (!empty($attachment_id[0])) ? '<img src="'.esc_url(wp_get_attachment_image_url($attachment_id[0],  array(432,400))).'" alt="listing image">' : '' ?>
                                        </div>

                                        <figcaption>
                                            <p><?= !empty($excerpt) ? esc_html(stripslashes($excerpt)) : ''; ?></p>
                                        </figcaption>
                                    </figure>

                                    <div class="article_content">
                                        <div class="content_upper">
                                            <h4 class="post_title">
                                                <a href="<?= esc_url(get_post_permalink(get_the_ID())); ?>"><?php echo esc_html(stripslashes(get_the_title())); ?></a>
                                            </h4>
                                            <p><?= (!empty($tagline)) ? esc_html(stripslashes($tagline)) : ''; ?></p>
                                            <?php

                                            /**
                                             * Fires after the title and sub title of the listing is rendered on the single listing page
                                             *
                                             *
                                             * @since 1.0.0
                                             */

                                            do_action('atbdp_after_listing_tagline');

                                            ?>
                                          
                                        </div>

                                        <div class="general_info">
                                            <ul>
                                                <!--Category Icons should be replaced later -->
                                                <li>
                                                    <p class="info_title"><?php echo __('Category:', ATBDP_TEXTDOMAIN);?></p>
                                                    <p class="directory_tag">

                                                        <span class="fa <?= esc_attr(get_cat_icon(@$single_parent->term_id)); ?>" area-hidden="true"></span>
                                                        <span> <?php if (is_object($single_parent)) { ?>
                                                                <a href="<?= get_home_url('', '/'); ?>?s=&at_biz_dir-category=<?=  $single_parent->name; ?>&post_type=at_biz_dir">
                                                                <?= $single_parent->name; ?>
                                                                </a>
                                                            <?php } else {
                                                               _e('Others', ATBDP_TEXTDOMAIN);
                                                            } ?>
                                                        </span>
                                                    </p>
                                                </li>
                                                <li><p class="info_title"><?php _e('Location:', ATBDP_TEXTDOMAIN);?></p>
                                                    <span><?= !empty($address) ? esc_html(stripslashes($address)) : ''; ?></span>
                                                </li>
                                            </ul>
                                        </div>

                                        <div class="read_more_area">
                                            <a class="btn btn-default" href="<?= get_post_permalink(get_the_ID()); ?>"><?php _e('Read More', ATBDP_TEXTDOMAIN); ?></a>
                                        </div>
                                    </div>
                                </article>
                            </div>
                        </div>

                    <?php }
                    } else {?>
                            <p><?php _e('No listing found.', ATBDP_TEXTDOMAIN); ?></p>
                <?php } ?>



            </div> <!--ends .row -->

            <div class="row">
                <div class="col-md-12">
                    <?php
                    the_posts_pagination(
                            array('mid_size'  => 2,
                            'prev_text' => '<span class="fa fa-chevron-left"></span>',
                            'next_text' => '<span class="fa fa-chevron-right"></span>',
                        ));
                    ?>
                </div>
            </div>
        </div>
    </section>
<?php
?>
<?php include __DIR__.'/style.php'; ?>
<?php get_footer(); ?>